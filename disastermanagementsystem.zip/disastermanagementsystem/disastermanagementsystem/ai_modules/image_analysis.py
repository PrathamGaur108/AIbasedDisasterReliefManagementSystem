import random
import os
import cv2
import numpy as np
from sklearn.model_selection import train_test_split
import torch
from torchvision import models, transforms
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report

#https://www.kaggle.com/datasets/varpit94/disaster-images-dataset

IMG_SIZE = 224
classes = {'low': 0, 'moderate': 1, 'severe': 2}

def load_images(data_dir):
    X, y = [], []
    for label in classes:
        folder = os.path.join(data_dir, label)
        for file in os.listdir(folder):
            path = os.path.join(folder, file)
            img = cv2.imread(path)
            if img is not None:
                img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))
                X.append(img)
                y.append(classes[label])
    return np.array(X), np.array(y)

X, y = load_images(r"C:\Users\prath\OneDrive\Documents\GCOEA\8th Sem\FY Project\AIDisasterManagementSystem\Scripts\disastermanagementsystem\disastermanagementsystem\disaster_images")

# Use ResNet18 as a feature extractor
resnet = models.resnet18(pretrained=True)
resnet = torch.nn.Sequential(*list(resnet.children())[:-1])  # Remove the final classification layer
resnet.eval()

# Transform image for PyTorch model
transform = transforms.Compose([
    transforms.ToPILImage(),
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
])

def extract_features(images):
    features = []
    with torch.no_grad():
        for img in images:
            input_tensor = transform(img).unsqueeze(0)  # Add batch dimension
            feat = resnet(input_tensor)
            features.append(feat.view(-1).numpy())  # Flatten output
    return np.array(features)

X_features = extract_features(X)

X_train, X_test, y_train, y_test = train_test_split(X_features, y, test_size=0.2, random_state=42)

clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)

# Evaluate
y_pred = clf.predict(X_test)
#print(classification_report(y_test, y_pred, target_names=classes.keys()))

def recommend_action(severity_class):
    if severity_class == 0:
        return "Minor damage. Local response sufficient."
    elif severity_class == 1:
        return "Moderate damage. Mobilize regional emergency services."
    elif severity_class == 2:
        return "Severe damage. Immediate national/international response required."

def analyze_satellite_image(image_path):
    img = cv2.imread(image_path)
    img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))
    
    with torch.no_grad():
        input_tensor = transform(img).unsqueeze(0)
        feature = resnet(input_tensor).view(-1).numpy().reshape(1, -1)
    
    pred = clf.predict(feature)[0]
    label = list(classes.keys())[list(classes.values()).index(pred)]
    return f"Predicted Severity: {label.title()}\nRecommendation: {recommend_action(pred)}"