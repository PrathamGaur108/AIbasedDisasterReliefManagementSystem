import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier

def reconstruction_plan(severity, type, area, popDensity, infraDamage):
    data = {
        'severity': [0, 2, 1, 1, 2],
        'disaster_type': ['Flood', 'Earthquake', 'Cyclone', 'Flood', 'Earthquake'],
        'area': [20, 100, 50, 80, 120],
        'pop_density': [500, 1200, 800, 1000, 1500],
        'infra_damage': [4, 9, 6, 8, 10],
        'recon_days': [30, 120, 60, 90, 150],
        'recon_cost': [2, 10, 5, 8, 12],
        'personnel_needed': [50, 200, 100, 160, 250],
        'resource_kits': [300, 1000, 600, 800, 1200],
        'priority': ['Low', 'High', 'Medium', 'Medium', 'High']
    }
    
    df = pd.DataFrame(data)
    
    # Encode categorical values
    le = LabelEncoder()
    df['disaster_type'] = le.fit_transform(df['disaster_type'])
    #df['disaster_type'] = le.transform([df['disaster_type']])
    disaster_type_encoded = le.transform([type])[0]
    df['priority'] = le.fit_transform(df['priority'])  # optional if used as target
    
    # Features and Targets
    X = df[['severity', 'disaster_type', 'area', 'pop_density', 'infra_damage']]
    y = df[['recon_days', 'recon_cost', 'personnel_needed', 'resource_kits']]  # priority could be a separate classifier
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    model = RandomForestRegressor()
    model.fit(X_train, y_train)
    
    predictions = model.predict(X_test)
    y_priority = df['priority']
    X_train2, X_test2, y_train2, y_test2 = train_test_split(X, y_priority, test_size=0.2)
    
    clf = RandomForestClassifier()
    clf.fit(X_train2, y_train2)
    priority_pred = clf.predict(X_test2)
    
    # Predict for a new disaster
    input_data = [[severity, disaster_type_encoded, area, popDensity, infraDamage]]
    recon_prediction = model.predict(input_data)
    priority_prediction = clf.predict(input_data)
    priority_label = le.inverse_transform([priority_prediction])[0]  # ✅ Just the classifier output
    
    plan = {
        'Days': recon_prediction[0][0],
        "Cost": recon_prediction[0][1],
        'Personnel': recon_prediction[0][2],
        "Resource_Kits": recon_prediction[0][3],
        "Priority_Level": priority_label
    }
    
    return plan

#print(reconstruction_plan(1, 'Earthquake', 3000, 50000, 9))