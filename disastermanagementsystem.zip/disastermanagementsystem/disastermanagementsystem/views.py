from django.shortcuts import render
from django.core.files.storage import FileSystemStorage
import os
import requests
import json
from django.http import JsonResponse
import cv2
import numpy as np
from sklearn.model_selection import train_test_split
import torch
from torchvision import models, transforms
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import classification_report
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import mean_squared_error, accuracy_score
from django.views.decorators.csrf import csrf_exempt

#openai.api_key = os.getenv("OPENAI_API_KEY")
MAP_API_KEY = os.getenv("MAP_API_KEY")
SATELLITE_API_KEY = os.getenv("SATELLITE_API_KEY")  # e.g., NASA, Sentinel Hub, etc.


def home(request):
    return render(request, "home.html")

IMG_SIZE = 224
classes = {'low': 0, 'moderate': 1, 'severe': 2}

def load_images(data_dir):
    X, y = [], []
    for label in classes:
        folder = os.path.join(data_dir, label)
        for file in os.listdir(folder):
            path = os.path.join(folder, file)
            img = cv2.imread(path)
            if img is not None:
                img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))
                X.append(img)
                y.append(classes[label])
    return np.array(X), np.array(y)

X, y = load_images(r"C:\Users\prath\OneDrive\Documents\GCOEA\8th Sem\FY Project\AIDisasterManagementSystem\Scripts\disastermanagementsystem\disastermanagementsystem\disaster_images")

# Use ResNet18 as a feature extractor
resnet = models.resnet18(pretrained=True)
resnet = torch.nn.Sequential(*list(resnet.children())[:-1])  # Remove the final classification layer
resnet.eval()

# Transform image for PyTorch model
transform = transforms.Compose([
    transforms.ToPILImage(),
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
])

def extract_features(images):
    features = []
    with torch.no_grad():
        for img in images:
            input_tensor = transform(img).unsqueeze(0)  # Add batch dimension
            feat = resnet(input_tensor)
            features.append(feat.view(-1).numpy())  # Flatten output
    return np.array(features)

X_features = extract_features(X)

X_train, X_test, y_train, y_test = train_test_split(X_features, y, test_size=0.2, random_state=42)

clf = RandomForestClassifier(n_estimators=100, random_state=42)
clf.fit(X_train, y_train)

# Evaluate
y_pred = clf.predict(X_test)
#accuracy = accuracy_score(y_test, y_pred)
#print(f"Accuracy: {accuracy * 100:.2f}%")
#print(classification_report(y_test, y_pred, target_names=classes.keys()))

def recommend_action(severity_class):
    if severity_class == 0:
        return "Minor damage. Local response sufficient."
    elif severity_class == 1:
        return "Moderate damage. Mobilize regional emergency services."
    elif severity_class == 2:
        return "Severe damage. Immediate national/international response required."

def analyze_satellite_image(image_path):
    img = cv2.imread(image_path)
    img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))
    
    with torch.no_grad():
        input_tensor = transform(img).unsqueeze(0)
        feature = resnet(input_tensor).view(-1).numpy().reshape(1, -1)
    
    pred = clf.predict(feature)[0]
    label = list(classes.keys())[list(classes.values()).index(pred)]
    #return f"Predicted Severity: {label.title()}\nRecommendation: {recommend_action(pred)}"
    return recommend_action(pred)

# Example usage
#print(predict_image("AA1DtrZX.jpg"))

def sda(request):
    result = None
    if request.method == 'POST' and request.FILES.get('satellite_image'):
        image = request.FILES['satellite_image']
        fs = FileSystemStorage()
        filename = fs.save(image.name, image)
        uploaded_file_url = fs.path(filename)
        result = analyze_satellite_image(uploaded_file_url)
    return render(request, 'sda.html', {'result': result})

def helpline(request):
    return render(request, 'helpline.html')

def about(request):
    return render(request, 'about.html')

def reconstruction_plan(severity, area, population, damage_score):
    # Simulated dataset
    np.random.seed(42)
    data = pd.read_csv(r"C:\Users\prath\OneDrive\Documents\GCOEA\8th Sem\FY Project\AIDisasterManagementSystem\Scripts\disastermanagementsystem\disastermanagementsystem\disaster_reconstruction.csv")
    
    df = pd.DataFrame(data)
    # Features and targets
    X = df[['severity', 'area_sqkm', 'population_affected', 'infra_damage_score']]
    y_reg = df[['days', 'cost_million', 'personnel', 'resource_kits']]
    le = LabelEncoder()
    y_class = le.fit_transform(df['priority'])
    
    # Split the data
    X_train, X_test, y_reg_train, y_reg_test, y_class_train, y_class_test = train_test_split(X, y_reg, y_class, test_size=0.2, random_state=42)
    
    # Train models
    regressor = RandomForestRegressor()
    classifier = RandomForestClassifier()
    
    regressor.fit(X_train, y_reg_train)
    classifier.fit(X_train, y_class_train)

    features = np.array([[severity, area, population, damage_score]])
    reg_preds = regressor.predict(features)[0]
    #accuracyR = accuracy_score(y_reg_test, reg_preds)
    #print(f"Regression Accuracy: {accuracyR}")
    class_pred = classifier.predict(features)[0]
    #accuracyC = accuracy_score(y_class_test, class_pred)
    #print(f"Classification Accuracy: {accuracyC}")
    return {
        'Days': int(reg_preds[0]),
        'Cost': int(reg_preds[1]),
        'Personnel': int(reg_preds[2]),
        'Resource_Kits': int(reg_preds[3]),
        'Priority_Level': le.inverse_transform([class_pred])[0]
        }
# Test the function
#print(reconstruction_plan(severity=8, area=150, population=30000, damage_score=7))


def reconstruction(request):
    result = None
    if request.method == 'POST':
        try:
            severity = int(request.POST['severity'])
            #dis_type = request.POST.get('dis_type')
            area = int(request.POST['area'])
            popDensity = int(request.POST['popDensity'])
            damage_score = int(request.POST['infraDamage'])
            result = reconstruction_plan(severity, area, popDensity, damage_score)
            return render(request, 'reconstruction.html', {'result': result})
        except Exception as e:
            return render(request, 'reconstruction.html', {'error': str(e)})
    else:
        return render(request, 'reconstruction.html')


def analyze_image(request):
    satellite_result = None
    if request.method == 'POST':
        lat = request.POST.get('latitude')
        lon = request.POST.get('longitude')
        # Example SentinelHub or NASA Open API request (pseudo code)
        url = f'https://api.satellite-data.org/v1/imagery?lat={lat}&lon={lon}&apiKey={SATELLITE_API_KEY}'
        response = request.get(url)
        if response.status_code == 200:
            # Assume image downloaded and stored locally
            satellite_image_path = '/path/to/downloaded/image.jpg'
            satellite_result = analyze_satellite_image(satellite_image_path)
        else:
            satellite_result = {"error": "Failed to retrieve satellite data."}
    return render(request, 'analyze_image.html', {'satellite_result': satellite_result})

'''
def reconstruction_plan(severity, type, area, popDensity, infraDamage):
    data = {
        'severity': [0, 2, 1, 1, 2],
        'disaster_type': ['Flood', 'Earthquake', 'Cyclone', 'Flood', 'Earthquake'],
        'area': [20, 100, 50, 80, 120],
        'pop_density': [500, 1200, 800, 1000, 1500],
        'infra_damage': [4, 9, 6, 8, 10],
        'recon_days': [30, 120, 60, 90, 150],
        'recon_cost': [2, 10, 5, 8, 12],
        'personnel_needed': [50, 200, 100, 160, 250],
        'resource_kits': [300, 1000, 600, 800, 1200],
        'priority': ['Low', 'High', 'Medium', 'Medium', 'High']
    }
    
    df = pd.DataFrame(data)
    
    # Encode categorical values
    le = LabelEncoder()
    df['disaster_type'] = le.fit_transform(df['disaster_type'])
    #df['disaster_type'] = le.transform([df['disaster_type']])
    disaster_type_encoded = le.transform([type])[0]
    df['priority'] = le.fit_transform(df['priority'])  # optional if used as target
    
    # Features and Targets
    X = df[['severity', 'disaster_type', 'area', 'pop_density', 'infra_damage']]
    #y = df[['recon_days', 'recon_cost', 'personnel_needed', 'resource_kits']]  # priority could be a separate classifier
    y = df['priority']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
    model = RandomForestRegressor()
    model.fit(X_train, y_train)
    
    predictions = model.predict(X_test)
    y_priority = df['priority']
    X_train2, X_test2, y_train2, y_test2 = train_test_split(X, y_priority, test_size=0.2)
    
    clf = RandomForestClassifier()
    clf.fit(X_train2, y_train2)
    priority_pred = clf.predict(X_test2)
    
    # Predict for a new disaster
    input_data = [[severity, disaster_type_encoded, area, popDensity, infraDamage]]
    recon_prediction = model.predict(input_data)
    priority_prediction = clf.predict(input_data)
    priority_label = le.inverse_transform([priority_prediction])[0]  #  the classifier output
    
    plan = {
        'Days': recon_prediction[0][0],
        "Cost": recon_prediction[0][1],
        'Personnel': recon_prediction[0][2],
        "Resource_Kits": recon_prediction[0][3],
        "Priority_Level": priority_label
    }
    
    return plan
'''